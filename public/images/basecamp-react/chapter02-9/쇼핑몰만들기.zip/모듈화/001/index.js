import Main from "./Main.js"

Main()